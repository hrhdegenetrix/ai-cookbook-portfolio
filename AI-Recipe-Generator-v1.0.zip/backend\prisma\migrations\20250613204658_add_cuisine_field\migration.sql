-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_recipes" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "servings" INTEGER NOT NULL DEFAULT 4,
    "prepTime" TEXT NOT NULL,
    "cookTime" TEXT NOT NULL,
    "ingredients" TEXT NOT NULL,
    "instructions" TEXT NOT NULL,
    "tips" TEXT,
    "cuisine" TEXT NOT NULL DEFAULT 'International',
    "isFavorite" BOOLEAN NOT NULL DEFAULT false,
    "rating" INTEGER,
    "personalNotes" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "originalIngredients" TEXT NOT NULL
);
INSERT INTO "new_recipes" ("cookTime", "createdAt", "description", "id", "ingredients", "instructions", "isFavorite", "originalIngredients", "personalNotes", "prepTime", "rating", "servings", "tips", "title", "updatedAt") SELECT "cookTime", "createdAt", "description", "id", "ingredients", "instructions", "isFavorite", "originalIngredients", "personalNotes", "prepTime", "rating", "servings", "tips", "title", "updatedAt" FROM "recipes";
DROP TABLE "recipes";
ALTER TABLE "new_recipes" RENAME TO "recipes";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
